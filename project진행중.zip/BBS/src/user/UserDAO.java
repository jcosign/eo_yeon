package user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {

	private Connection conn;
	private PreparedStatement pstant;
	private ResultSet rs;
	
	public UserDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3360/BBS";
			String dbID = "root";
			String dbPassword = "root";	//02:08
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
