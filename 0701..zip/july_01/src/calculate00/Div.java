package calculate00;

class Div extends Calc{
	void setValue(int a, int b) {
		this.a=a;
		this.b=b;
	}
	
		int Calc() {
			return a/b;
	}
}
