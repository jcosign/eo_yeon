package calculate00;

import java.util.Scanner;

class Add extends Calc{
	void setValue(int a, int b) {
		this.a=a;
		this.b=b;
	}

	int Calc() {
		return a+b;
	}
}
