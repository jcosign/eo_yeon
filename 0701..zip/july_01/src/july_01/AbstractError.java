package july_01;

public class AbstractError {

	public static void main(String[] args) {
		Dobject obj = new Line();
		obj.draw();
		

	}

}
