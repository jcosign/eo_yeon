package july_01;

public class Circle extends Dobject{

	@Override
	public void draw() {
		System.out.println("Circle");
		
	}

}
