package july_01;

public class Ract extends Dobject{

	@Override
	public void draw() {
		System.out.println("Rect");
		
	}

}
