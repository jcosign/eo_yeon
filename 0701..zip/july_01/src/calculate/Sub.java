package calculate;

public class Sub extends Calc{
	@Override
	protected
	int calculate() {
		return a-b;
	}
}
