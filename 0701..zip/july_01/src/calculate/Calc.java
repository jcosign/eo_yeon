package calculate;

abstract public class Calc {
	int a, b;

	void setValue(int a, int b) {
		this.a=a;
		this.b=b;
	}

	protected abstract int calculate();
}