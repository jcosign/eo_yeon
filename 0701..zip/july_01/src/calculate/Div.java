package calculate;

public class Div extends Calc{
	@Override
	protected
	int calculate() {
		return a/b;
	}
}
