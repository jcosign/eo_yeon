package kr.ac.kopo;

public class MyVo {
	
	private int myNo;
	private String myId;
		
	public int getMyNo() {
		return myNo;
	}
	public void setMyNo(int myNo) {
		this.myNo = myNo;
	}
	public String getMyId() {
		return myId;
	}
	public void setMyId(String myId) {
		this.myId = myId;
	}
	
	

}
