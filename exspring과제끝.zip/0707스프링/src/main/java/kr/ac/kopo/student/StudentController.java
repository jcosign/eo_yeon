package kr.ac.kopo.student;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class StudentController {
	// @Autowired,@Inject,@Resource 중 하나를 사용하여 스프링에 등록된 객체를 주입
	@Resource(name = "studentService")
	private StudentService studentService;

	@RequestMapping("/student/list.do")
	public String list(Map modelMap) {
		List<StudentVo> list = studentService.selectStudentList();
		modelMap.put("stuList", list);
		return "student/stuList";
	}

	@RequestMapping(value = "/student/add.do", method = RequestMethod.GET)
	public String addform() {
		return "student/stuAddForm";
	}

	@RequestMapping(value = "/student/add.do", method = RequestMethod.POST)
	public String add(StudentVo vo) {

		int num = studentService.insertStudent(vo);
		System.out.println(num + "媛쒖쓽 �젅肄붾뱶 異붽�");
		return "redirect:/student/list.do";
	}

	@RequestMapping(value = "/student/edit.do", method = RequestMethod.GET)
	public String editform(String stuNo, Map modelMap) {
		StudentVo vo = studentService.selectStudent(stuNo);
		modelMap.put("stuVo", vo);
		return "student/stuEditForm";
	}

	@RequestMapping(value = "/student/edit.do", method = RequestMethod.POST)
	public String edit(StudentVo vo) {

		int num = studentService.updateStudentVo(vo);
		System.out.println(num + "媛쒖쓽 �젅肄붾뱶 蹂�寃�");
		return "redirect:/student/list.do";

	}

	@RequestMapping(value = "/student/del.do")
	public String delStudent(String stuNo) {
		int num = studentService.delStudent(stuNo);
		System.out.println(num + "紐낆쓽 �쉶�썝�궘�젣");
		return "redirect:/student/list.do";
	}
}
