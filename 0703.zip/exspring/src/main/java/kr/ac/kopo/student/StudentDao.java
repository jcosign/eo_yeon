package kr.ac.kopo.student;

import java.util.List;

public interface StudentDao {

	List<StudentVo> selectStuList();

	StudentVo selectStudent(int stuNo);

	int insertStudent(StudentVo vo);

	int updateStudent(StudentVo vo);

	int deletStudent(int StuNo);

}