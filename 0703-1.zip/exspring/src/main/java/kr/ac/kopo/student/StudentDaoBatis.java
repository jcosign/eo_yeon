package kr.ac.kopo.student;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import kr.ac.kopo.comm.MyBatisUtils;
import kr.ac.kopo.member.MemberVo;
import sun.security.jca.GetInstance;

public class StudentDaoBatis implements StudentDao{
	
	private SqlSessionFactory sqlSessionFactory = MyBatisUtils.getSqlSessionFactory();

	private StudentDaoBatis() { }
	private static StudentDao studentDao = new StudentDaoBatis();
	public static StudentDao getInstance() {
		return studentDao;
	}
	
	@Override
	public List<StudentVo> selectStuList() {
		List<StudentVo> list = null;
	try (SqlSession session = sqlSessionFactory.openSession()) {
		list = session.selectList("kr.ac.kopo.student.StudentDao.selectStudentList");
	}
		return null;
	}
	@Override
	public StudentVo selectStudent(int stuNo) {
		MemberVo vo = null;
		try (SqlSession session = sqlSessionFactory.openSession()) {
			vo = session.selectOne("kr.ac.kopo.member.MemberDao.selectMember", memId);
		}
		return null;
	}
	@Override
	public int insertStudent(StudentVo vo) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int updateStudent(StudentVo vo) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int deletStudent(int StuNo) {
		// TODO Auto-generated method stub
		return 0;
	}