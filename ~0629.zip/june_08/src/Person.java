

public class Person {
	public String name;
	public int age;

	public Person() {
	}

	public Person(String s) {
		name = s;
	}

	public String getName() {
		return name;
	}



}
