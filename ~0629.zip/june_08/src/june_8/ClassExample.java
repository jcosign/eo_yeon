package june_8;

public class ClassExample {

	public static void main(String[] args) {
		Person aPerson = new Person("ȫ�浿 ");
		
		aPerson.age = 39;
		String yourName = aPerson.getName();
		
		System.out.println(yourName + "���̴�" + aPerson.age + "�Դϴ�.");

	}

}
