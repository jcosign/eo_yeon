
public class Ex24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int val = 10;
		int nextx;
		
		nextx = ++val;
		System.out.printf("nextx:%d, val:%d\n", nextx, val);
		
		nextx = val++;
		System.out.printf("nextx:%d, val:%d\n", nextx, val);
		
		nextx = --val;
		System.out.printf("nextx:%d, val:%d\n", nextx, val);
		
		nextx = val--;
		System.out.printf("nextx:%d, val:%d\n", nextx, val);
		
	}

}
