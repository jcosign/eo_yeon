package may_20;

import java.util.Scanner;

public class Ex0400 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s =new Scanner(System.in);

		int[] lotto = new int[6];
		int[] num = new int[6];

		for (int i = 0; i < lotto.length; i++) {
			lotto[i] = (int)(Math.random()*46);
		}

		while(true) {

			System.out.printf("%s %s %s %s\n", "1.�ζǹ�ȣ �ڵ�����", "2.�ζǹ�ȣ �Է�", "3.��÷Ȯ��", "4.����");
			int n = s.nextInt(); 

			switch(n) {

			case 1:

				for(int i=0; i<lotto.length-1; i++) {
					int m = i;

					for(int j=i+1; j<6; j++) {
						if(lotto[m]>lotto[j]) {
							m=j;
						}
					}

					int tmp = lotto[i];
					lotto[i] = lotto[m];
					lotto[m] = tmp;

				}

				for (int j = 0; j < lotto.length; j++) {
					System.out.printf("%5d", lotto[j]);
				}
				System.out.println();
				
			case 2:
				System.out.println("�ζ� ��ȣ �Է�");
				for(int i=0; i<num.length; i++) {
					num[i] = s.nextInt();

				}
				
			case 3:
				for(int i=0; i<num.length-1; i++) {
					int m = i;

					for(int j=i+1; j<5; j++) {
						if(num[m]>num[j]) {
							m=j;
						}
					}

					int tmp = num[i];
					num[i] = num[m];
					num[m] = tmp;

				}
				for (int j = 0; j < num.length; j++) {
					System.out.printf("%3d",num[j]);
					System.out.println();
					System.out.printf("%3d",lotto[j]);
					System.out.println();
					}
				}
			}

		}

	}


