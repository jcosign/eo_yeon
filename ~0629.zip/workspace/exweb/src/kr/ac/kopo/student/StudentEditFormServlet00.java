package kr.ac.kopo.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.ac.kopo.student.StudentVo;

@WebServlet("/student/editform.do")
public class StudentEditFormServlet00 extends HttpServlet{
	StudentDaoJdbc studentDao = new StudentDaoJdbc();

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String no = req.getParameter("stuNo");
		StudentVo vo = studentDao.selectStudent(no);
		
		req.setAttribute("stuVo", vo);
		
		req.getRequestDispatcher("/WEB-INF/jsp/student/stuEditForm.jsp").forward(req, resp);
		
	}
	}

	






//package kr.ac.kopo.student;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//
////������ �ּ�â��
////http://localhost:8000/exweb/student/edit.do?stuno=a001
////�� �Է��ϰ� ����Ű�� �Է��ϸ�,
////������ ȭ�鿡 �л� ������ �Է��� �� �ִ� ���� �Է� ������Ʈ�� ����ϰ�,
////������ ���̽����� ���̵� 'a001'�� �л��� ������ ��ȸ�Ͽ�
////�� ������ �Է� ������Ʈ�鿡 ���� ������ ���
//
////a001 ���� ���̵� ���� ������ �� ����.
//
//@WebServlet("/student/editform.do")
//public class StudentEditFormServlet00 extends HttpServlet {
//	StudentDaoJdbc studentDao = new StudentDaoJdbc();
////   {
////   try {
////      Class.forName("oracle.jdbc.OracleDriver");
////   } catch (ClassNotFoundException e) {
////      e.printStackTrace();
////   }
////   }
////   
////   String url = "jdbc:oracle:thin:@localhost:1521:xe";
////   String user = "com";
////   String password = "com01";
////   
//
//   @Override
//   protected void service(HttpServletRequest req, HttpServletResponse resp) 
//      throws ServletException, IOException {
//	   String no = req.getParameter("stuNo");
//		StudentVo vo = studentDao.selectStudent(no);
//		
//		req.setAttribute("stuVo", vo);
//		
//		req.getRequestDispatcher("/WEB-INF/jsp/student/stuEditForm.jsp").forward(req, resp);
//		
//	}
//	}
//   
//   
////   resp.setContentType("text/html");
////   resp.setCharacterEncoding("UTF-8");
////   PrintWriter out = resp.getWriter();
////   
////   out.println("<!DOCTYPE html>                  ");
////   out.println("<html>                           ");
////   out.println("<head>                           ");
////   out.println("<meta charset='UTF-8'>           ");
////   out.println("<title>�л� ����</title>");
////   out.println("</head>                          ");
////   out.println("<body>                           ");
////   
////   out.println("   <h1>�л� ���� ����</h1>   ");
////   
////    String No = req.getParameter("stu_no");
////    
////    
////    String sql = "SELECT stu_no, stu_name, stu_score FROM student WHERE stu_no = ?";
////   
////    try (
////          Connection conn = DriverManager.getConnection(url, user, password);
////          PreparedStatement pstmt = conn.prepareStatement(sql);                                                          
////          ) 
////          {
////           pstmt.setString(1, No); //No ���� ù ��° ����ǥ�� ä����.                      
////            try (ResultSet rs = pstmt.executeQuery();) //������ ���ڵ���� ����Ű�� �ִ� resultset �� ��ȯ                             
////               {    
////               if(rs.next()) {
////               String stuno = rs.getString("stu_no");
////               String stuname = rs.getString("stu_name");
////               int stuscore = rs.getInt("stu_score");
////               out.println("<a href='" + req.getContextPath() + "/student/edit.do?stu_no=" +stuno + "'>"+ stuno + "</a>"+":"+stuname+":"+stuscore);
////               out.println("      <form action='" + req.getContextPath() + "/student/edit.do' method='post'> ");
////        
////               out.println("      �й�: <input text='text' name='stu_no' value='" + stuno + "' /><br/>        ");
////               out.println("      �̸�: <input text='text' name='stu_name'value='" + stuname + "'/><br/>      ");
////               out.println("      ����: <input text='text' name='stu_score'value='" + stuscore + "'/><br/>    ");
////               out.println("      <input type='submit' value='����' />                                        ");
////               out.println("</form> ");               
////               }                                                          
////               }           
////            
////    } catch (SQLException e) {
////       e.printStackTrace();
////    }
////   
////
////   out.println("</body>                          ");
////   out.println("</html>                          ");
////}
////}
