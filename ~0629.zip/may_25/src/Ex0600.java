import java.util.Scanner;

public class Ex0600 {

	//����
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		int[] score = null;
		
		System.out.println("���������� �Է��Ͻÿ�.");
		System.out.println("score1:");
		System.out.println("score2:");
		System.out.println("score3:");
		
		int sum = 0;
		for(int i = 0; i < score.length; i++) {
			sum += score[i];
		}
		System.out.println();
		
//			System.out.printf("����%d: ", i+1);
//			a[i] = s.nextInt();
//		}
//		for (int i = 0; i < a.length; i++) {
//			System.out.printf("%4d", a[i]);
//		}

	}

}
