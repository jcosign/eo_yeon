import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);

		while(true) {

			
				System.out.println("\tMENU");
				System.out.println("(1) ��� ���  (2) �Ҽ� �Ǵ�  (3) ����");
				int n = s.nextInt();


				if(n == 3 ) {
					System.out.println("���α׷� ����"); 
					return;
				}

				if(!(n >= 1 && n <= 3)) {
					System.out.println("�߸��Է�");
					continue;
				}

				System.out.println("������ ����: ");
				int num = s.nextInt();

				switch(n) {
				case 1:div(num); break;
				case 2:prime(num); break;
				}

			}
		}

		/////////////////////////////////////////
		public static void div(int x) {
			for(int i=1; i<=x; i++) {
				if(x%i == 0)
					System.out.printf("%4d", i);
			}
		}
		////////////////////////////////////////
		public static void prime(int x) {
			int i;

			for(i = 2; i < x; i++) {
				if(x % i == 0) 
					break;
			}
			if(i == x) 
				System.out.printf("%d�� �Ҽ��Դϴ�.\n", x);
			else 
				System.out.printf("%d�� �Ҽ��� �ƴմϴ�.\n", x);
			
		}
	
	}


