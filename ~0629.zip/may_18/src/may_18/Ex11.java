package may_18;

import java.util.Scanner;

public class Ex11 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int i = 1;
		int sum = 0;
		
		while(i <= 10) {
		 sum += i; // sum = sum + i;
		 i++;
		}

		System.out.printf("��ü��: %d\n", sum);
	}

}
