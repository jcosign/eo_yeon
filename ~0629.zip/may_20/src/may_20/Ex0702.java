package may_20;

import java.util.Scanner;

public class Ex0702 {

	public static void main(String[] args) {
		for(int i = 9; i>=0; i--) 
		{ for(int j =0; j<=i; j++) 
		{ System.out.print("*"); } 
		System.out.println(); }

		
//		Scanner s = new Scanner(System.in);
//		int i = 1;
//		for(int j=5;j<=i;j--) {			
//			for(i=5;i>=5;i--) {		
//			System.out.printf("*");
//			if(j==i) {
//			System.out.println();
//			}
//		}
//	}

	}

}
