package may_20;

public class Ex01 {

	public static void main(String[] args) {
		int i =1;
		
		do {
			System.out.println("Hello~~");
			i++;
		}while(i<=5);
	

	}

}
