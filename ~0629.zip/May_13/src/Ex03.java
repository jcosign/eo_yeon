
public class Ex03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 20;
		int y = 50;
		int max;
		
		// ���ǽ�? True_value:False_value;
		max = (x>y)? x: y;
				//��ȣ�� �ɼ�
		System.out.printf("�ִ�:%d\n", max);
		
	}

}
