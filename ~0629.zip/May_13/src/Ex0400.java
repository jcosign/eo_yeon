import java.util.Scanner;

public class Ex0400 {

	public static void main(String[] args) {
		//������ 3�� �Է��� �ִ� ���

		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		int b = scan.nextInt();
		int c = scan.nextInt();
		
		int max = a>b? a: b;
		//System.out.println(max);
		
		//int max2 = b>c? b: c;
		//System.out.println("�ִ�: " + max2);
		
		//int max3 = c>a? c: a;
		max = max>c? max:c;
		System.out.println("�ִ�: " + max);
		
	}
	

}
