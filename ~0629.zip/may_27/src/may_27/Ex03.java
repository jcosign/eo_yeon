package may_27;

public class Ex03 {

	public static void main(String[] args) {
		int[] arr = new int[5];
		int max;
		
		for (int j = 0; j < arr.length; j++) {
			arr[j] = (int)(Math.random()*101);
		}
		
		max = arr[0];
		
		for (int i = 1; i < arr.length; i++) {
			if(max < arr[i])
				max = arr[i];
		}

		for (int i = 0; i < arr.length; i++) {
			System.out.printf("%4d", arr[i]);
			
		}
		
		System.out.printf("\n�ִ�:%d\n", max);
	}

}
