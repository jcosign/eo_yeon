package may_27;

public class Ex04 {

	private static int[] a;

	public static void main(String[] args) {
		//ĥ�ǳ���(�ٽ�����)
		
//		for (int i = 0; i < 4; i++) {
//			int m = i;
			
			
//			for (int j = i+1; j < 5; j++) {
//				a = null;
//				if (a[m] > a[i]) {
//					m = j;
//				}
//				{
//					tmp = a[i];
//					a[i] = a[m];
//					a[m] = tmp;
				}
			
//			}
		}
			
//		}
	

