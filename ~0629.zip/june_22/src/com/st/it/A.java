package com.st.it;

public class A {

	public int p;

	private int n;
	public void setN(int n) {
		this.n = n;
	}
	public int getN() {
		return n;
	}

}
