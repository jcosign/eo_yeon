package pakage03;

public class ConstructorEx02 {

	public static void main(String[] args) {
		B b;
		b = new B(5);
	}
}
