package june_1;

import java.util.Scanner;

public class Ex0600 {

	public static void main(String[] args) {
		// ������ ���� �߻���Ų �� �� �� ���� �ִ��� ���Ͻÿ�.
		Scanner s = new Scanner(System.in);

		int[][] arr = new int[3][4];

		for (int i = 0; i < arr.length; i++) {
//			System.out.printf("%d��: \n", i+1);
			int max = arr[i][0];
			for (int j = 0; j < arr[i].length-1; j++) {
//				arr[i][j] = s.nextInt();
				arr[i][j] = (int)(Math.random()*100+1);
				
				if(max < arr[i][j]) max = arr[i][j];
			
			}
			arr[i][3] = max;
		}
	
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length-1; j++) {
				System.out.printf("%5d",arr[i][j]);
			}
			System.out.printf("\t%d���� �ִ�: %d", i+1, arr[i][3]);
			System.out.println();
		}
	}
}
