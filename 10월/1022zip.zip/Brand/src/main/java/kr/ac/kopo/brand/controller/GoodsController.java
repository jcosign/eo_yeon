package kr.ac.kopo.brand.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import kr.ac.kopo.brand.model.Goods;
import kr.ac.kopo.brand.model.Point;
import kr.ac.kopo.brand.service.GoodsService;
import kr.ac.kopo.brand.service.OrdersService;
import kr.ac.kopo.brand.util.Pager;

@Controller
@RequestMapping("/goods")
public class GoodsController {
   final String path = "goods/";

   @Autowired
   GoodsService service;
   
   @Autowired
   OrdersService serviceOrders;

   final String uploadPath = "d://upload/";
   
   @GetMapping("/order")
   String order(HttpSession session) {
      @SuppressWarnings("unchecked")
      Map<Integer, Goods> cart = (Map<Integer, Goods>) session.getAttribute("cart");
      if(cart == null) {
         cart = new HashMap<Integer, Goods>();
         
         session.setAttribute("cart", cart);
      }
      
      Point point = (Point) session.getAttribute("user");      
      
      serviceOrders.order(point, cart);
      
      return "redirect:list";
   }
   
   @GetMapping("/cart")
   String cart(Integer goodsid, HttpSession session) {
      @SuppressWarnings("unchecked")
      Map<Integer, Goods> cart = (Map<Integer, Goods>) session.getAttribute("cart");
      if(cart == null) {
         cart = new HashMap<Integer, Goods>();
         
         session.setAttribute("cart", cart);
      }
      
      if(goodsid != null) {
         Goods item = service.item(goodsid);
         
         Goods goods = cart.get(goodsid);
         if(goods == null)         
            cart.put(goodsid, item);
         else
            goods.setQuantity( goods.getQuantity() + 1 );	//이게 뭐지..?
      }
      
      return path + "cart";
   }
   
   @GetMapping("/dummy")
   String dummy() {
      service.dummy();
      
      return "redirect:list";
   }
   
   @GetMapping("/init")
   String init() {
      service.init();
      
      return "redirect:list";
   }
   
   @GetMapping({"", "/list"})
   String list(Model model, Pager pager) {
      List<Goods> list = service.list(pager);
      
      model.addAttribute("list", list);
      
      return path + "list";
   }
   
   @GetMapping("/add")
   String add() {
      return path + "add";
   }   
   @PostMapping("/add")
   String add(Goods item) {
//      MultipartFile upload = item.getUploadFile();
//      
//      if(upload != null && upload.getSize() > 1) {
//         
//         try {
//            String filename = upload.getOriginalFilename();
//            
//            item.setCover(filename);
//            
//            upload.transferTo(new File(uploadPath  + filename));
//            
//            service.add(item);
//         } catch (IllegalStateException e) {
//            e.printStackTrace();
//         } catch (IOException e) {
//            e.printStackTrace();
//         }
//      } 
	   	service.add(item);
      
      return "redirect:list";
   }
   
   @GetMapping("/{goodsid}/update")
   String update(@PathVariable int goodsid, Model model) {
      Goods item = service.item(goodsid);
      
      model.addAttribute("item", item);
      
      return path + "update";
   }
   @PostMapping("/{goodsid}/update")
   String update(@PathVariable int goodsid, Goods item) {
      service.update(item);
      
      return "redirect:../list";
   }
   
   @GetMapping("/{goodsid}/delete")
   String delete(@PathVariable int goodsid) {
      service.delete(goodsid);
      
      return "redirect:../list";
   }
   
}