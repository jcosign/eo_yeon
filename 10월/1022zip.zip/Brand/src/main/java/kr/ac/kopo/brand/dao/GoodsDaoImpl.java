package kr.ac.kopo.brand.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.brand.model.Goods;
import kr.ac.kopo.brand.util.Pager;

@Repository
public class GoodsDaoImpl implements GoodsDao {

	@Autowired
	SqlSession sql;
	
	@Override
	public int total(Pager pager) {
		return sql.selectOne("goods.total", pager);
	}

	@Override
	public List<Goods> list(Pager pager) {
		return sql.selectList("goods.list", pager);
	}

	@Override
	public void add(Goods item) {
		sql.insert("goods.add", item);
	}

	@Override
	public Goods item(int goodsid) {
		return sql.selectOne("goods.item", goodsid);
	}

	@Override
	public void update(Goods item) {
		sql.update("goods.update", item);
	}

	@Override
	public void delete(int goodsid) {
		sql.delete("goods.delete", goodsid);
	}

}
