package kr.ac.kopo.brand.dao;

import java.util.List;

import kr.ac.kopo.brand.model.Goods;
import kr.ac.kopo.brand.util.Pager;

public interface GoodsDao {

	List<Goods> list(Pager pager);

	void add(Goods item);

	void delete(int goodsid);
	
	void update(Goods item);
	
	Goods item(int goodsid);
	
	int total(Pager pager);
	
//	void init();

//	void dummy();

	
}
