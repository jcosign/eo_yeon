package kr.ac.kopo.brand.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.brand.dao.GoodsDao;
import kr.ac.kopo.brand.model.Goods;
import kr.ac.kopo.brand.util.Pager;

@Service
public class GoodsServiceImpl implements GoodsService {

	@Autowired
	GoodsDao dao;

	@Override
	public List<Goods> list(Pager pager) {
		int total = dao.total(pager);

		pager.setTotal(total);

		return dao.list(pager);
	}

	@Override
	public void add(Goods item) {
		dao.add(item);
	}

	@Override
	public Goods item(int goodsid) {
		return dao.item(goodsid);
	}

	@Override
	public void update(Goods item) {
		dao.update(item);
	}

	@Override
	public void delete(int goodsid) {
		dao.delete(goodsid);
	}

	@Override
	public void dummy() {
		for(int index=1; index < 100; index++) {
			Goods item = new Goods();
			
			item.setGoodsid(index);
			item.setGoodsname("제품명 " + index);
			item.setKind("종류" + index);
			item.setPrice(index * 1000);
			
			dao.add(item);
		}
		
	}

	@Override
	public void init() {
		for(int index=1; index < 100; index++)
			dao.delete(index);		
	}


}
