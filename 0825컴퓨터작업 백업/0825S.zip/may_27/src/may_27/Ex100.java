package may_27;

import java.util.Arrays;
import java.util.Scanner;

public class Ex100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s =new Scanner(System.in);

		int[] lotto = new int[6];
		int[] num = new int[6];
		int[] num1 = new int[6];
		int cnt = 0;

		while(true) {
			
			for (int i = 0; i < lotto.length; i++) {
				lotto[i] = (int)(Math.random()*46+1);
			}

			System.out.printf("%s %s %s %s\n", "1.�ζǹ�ȣ �ڵ�����", "2.�ζǹ�ȣ �Է�", "3.��÷Ȯ��", "4.����");
			int n = s.nextInt(); 

			switch(n) {

			case 1:

				for(int i=0; i<lotto.length-1; i++) {
					int m = i;

					for(int j=i+1; j<6; j++) {
						if(lotto[m]>lotto[j]) {
							m=j;
						}
					}

					int tmp = lotto[i];
					lotto[i] = lotto[m];
					lotto[m] = tmp;

				}

				for (int j = 0; j < lotto.length; j++) {
					System.out.printf("%5d", lotto[j]);
					num1[j] = lotto[j];
					System.out.printf("%5d", num1[j]);
				}
				Arrays.fill(lotto,0);
				
				
				System.out.println();
				break;

			case 2:
				System.out.println("�ζ� ��ȣ �Է�");
				for(int i=0; i<num.length; i++) {
					num[i] = s.nextInt();
				}
				break;

			case 3:
				for(int i=0; i<num1.length; i++) {
					if(num1[i] == 0) {
						System.out.println("��ȣ�� �������� �ʾҽ��ϴ�");
					}
				}
				cnt = 0;
				
				for(int i=0; i<lotto.length; i++) {
					for(int j=0; j<num.length; j++) {
						if(num1[i]==num[j]) {
							cnt++;
						}
					}
				}
				System.out.println(cnt);
				
				break;
			case 4:
				System.out.println("���α׷��� �����մϴ�");
				System.exit(0);
				break;
			}
		}
	}
}
