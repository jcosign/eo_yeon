package may_27;

import java.math.MathContext;

public class Ex09 {

	public static void main(String[] args) {
		int[] freq = new int[10];
		
		for (int i = 0; i < 100; i++) {
			int n = (int)(Math.random()*10);
			freq[n]++;
//			���� ǥ��: freq[(int)(Math.random()*10)]++;
			
			}
		int m = 0;
		
		for (int i = 0; i < freq.length; i++) {
			if(freq[i]>freq[m])
				m = i;
		}
		
		for (int i = 0; i < freq.length; i++) {
			System.out.printf("%d:%4dȸ\n",i,freq[i]);
		}
		System.out.printf("\n�ֺ�:%d, �ֺ��� �󵵼�:%d\n", m, freq[m]);
	}

	}

