package may_27;

import java.util.Scanner;

public class Ex0200 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int[] score = new int[5];
		int sum = 0;
//		String[] intarray;
		
		for (int i = 0; i < score.length; i++) {
			System.out.printf("%d�� ����: ",i);
			score[i] = s.nextInt();
		}

	}

}
