package may_20;

import java.util.Scanner;

public class Ex1000 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.println("���ڸ� �Է��Ͻÿ�:");
		int n = scan.nextInt();

		for(int i=1;i<=n;i++) {			
			for(int j=1;j<=i;j++) {		
				System.out.printf("%d ",j);
				if(j==i) {
					System.out.println();
					}
			}
		}
	}
}
