package may_18;

import java.util.Scanner;

public class Ex10 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("���~?");
		int i = 1;
		int num = scan.nextInt();
		
		while(i <= 9) {
		System.out.printf(" %d x %d = %d\n", num, i, num*i);
		i++;
		}
	}

}
