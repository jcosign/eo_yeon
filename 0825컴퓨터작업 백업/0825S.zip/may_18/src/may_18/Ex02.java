package may_18;
import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		System.out.println("����ǥ��: ");
		int income = scan.nextInt();
		double tax;
		
		if(income <= 1000)
			tax = income * 0.08;
		else if(income <= 4000)
			tax = income * 0.17;
		else if(income <= 8000)
			tax = income * 0.26;
		else 
			tax = income * 0.35;
			System.out.println("�ҵ漼�� "+ tax + "�����Դϴ�.");
		
	}

}
