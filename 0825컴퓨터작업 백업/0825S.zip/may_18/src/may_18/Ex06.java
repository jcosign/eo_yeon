package may_18;

import java.util.Scanner;

public class Ex06 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		for(int i = 1; i<=5; i++)
			System.out.println((int)(Math.random()*3)+1);
//		0<=Math.random()<1	double type value
//		(int)(Math.random()*10 => 0<= ~ <=9
//		(int)(Math.random()*3 => 0<= ~ <=2
//		(int)(Math.random()*3+1 => 1<= ~ <=3
		
	
		
	}

}
