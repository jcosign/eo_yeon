/*# 폴더 구조
 * Java Resources 
 * - src/main/java : *.java
 * - src/main/resource : *.java를 제외한 파일들(*.xml,*.propertise,..)
 * - src/main/webapp : *.html, *.css, *.js, *.jpg ... 파일들
 * 
 * src/main/webapp 폴더가 배포 폴더로서,
 * Dynamic Web Project의 WebContent 폴더처럼 생각하고 사용
 * 
 * - src/test/java : 테스트를 위한 *.java
 * - src/test/resource : 테스트를 위한 *.java를 제외한 파일들(*.xml, *.properties,..)
 * 
 * # 설정 파일
 * src/main/resource/log4j.xml : Log4j라는 로그 라이브러리 설정 파일
 * src/main/webapp/WEB-INF/web.xml : 웹애플리케이션 전체 설정 파일					*/
// src/main/webapp/WEB-INF/spring/*/*.xml : 스프링프레임워크 설정 파일
/* pom.xml : 프로젝트 빌드 도구인 메이븐(MAVEN) 설정 파일
 * 
 * 자바 빌드 도구 : ANT -> Maven -> Gradle
*/

package kr.ac.kopo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/*@Controller의 @RequestMapping메서드는 실행결과로서 스프링에게 모델과 뷰 정보를 알려주....
 * 모델 : 응답에 포함되어야하는 데이터 (JSP에서 꺼내서 사용할 데이터)
 * 뷰 : 응답 화면 출력을 담당하는 객체 (어떤 JSP로 이동할 것인지에 대한 정보)*/
/**
 * Handles requests for the application home page.
 */
@Controller // 웹 요청을 받아서 실행되는 클래스임을 표시 (서블릿과 유사한 역할)
public class HomeController {
	// 로그 출력을 위한 로거 객체 가져오기
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
//	@RequestMapping으로 어떤 주소와 요청방식으로 요청이 왔을 때 실행될 메서드인지 설정 
	@RequestMapping(value = "/home.do", method = RequestMethod.GET) // "/home.do"로 GET방식이 오면 이 메서드를 실행
	public String home(Locale locale, Model model) {
		// 로그 출력
		logger.info("Welcome home! The client locale is {}.", locale);

		Date date = new Date(); // 현재 시간을 담은 객체 생성
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		String formattedDate = dateFormat.format(date); // 날짜/시간을 현재 로케일에 맞는 형태의 문자열로 변환

		// 모델에 "serverTime"라는 이름으로 formattedDate 변수값을 저장
		// JSP에서는 ${serverTime}라는 표현으로 formattedDate 변수값을 사용가능
		model.addAttribute("serverTime", formattedDate);

		// 화면출력을 위해 이동해야할 뷰(JSP)의 이름을 반환
		return "home"; // "/WEB-INF/views/home.jsp"
	}

	/*
	 * http://localhost:8000/kopo/test.do 주소로 요청을 보내면, test.jsp 화면이 나오도록 구현
	 */
//	@RequestMapping(value = "/test.do", method = RequestMethod.GET)	
//	@RequestMapping(value = "/test.do")	//method를 생략하면 요청방식에 상관없이 실행		//, method = RequestMethod.GET)
	@RequestMapping("/test.do") // method를 생략하면 요청방식에 상관없이 실행 //, method = RequestMethod.GET)
	public String test(@RequestParam(name = "myNo") String no, // "myNo"라는 이름의 파라미터값을 이 변수에 저장
//			String myNo, 	//"myNo"변수명이 파라미터명과 같은 경우에는 @RequestParam 생략 가능 (자동형변환가능)
			int myNo, // "myNo"변수명이 파라미터명과 같은 경우에는 @RequestParam 생략 가능 (자동형변환가능)
			@ModelAttribute("mvo") MyVo mv, // 사용자가 정의한 객체의 변수에는 동일한 이름의 파라미터값이 자동저장
//			@ModelAttribute 를 사용하여 모델에 지정한 이름으로 추가 기능
			MyVo vo, // 파라미터를 받기 위한 객체는 자동으로 모델에 추가
			// 모델에 저장되는 이름은 타입(클래스명)의 첫글자만 소문자로 바꾼 이름을 사용(헷갈리니 주의)
			Model model, ModelMap modelMap, Map map) {
		System.out.println("myNo:" + no); // http://localhost:8000/kopo/test.do?myNo=123
		System.out.println("myNo:" + myNo);
		System.out.println("mv의 myNo:" + mv.getMyNo());
		System.out.println("mv의 myId:" + mv.getMyId());

		String s = "Hello Spring!";
//		모델에 데이터를 추가(저장)하는 방법
//		인자로 받은 Model, ModelMap, Map 객체에 데이터를 저장
		model.addAttribute("modelVal", s);
		modelMap.addAttribute("modelMap", s);
		map.put("mapVal", s);
//		map.put("mvo", mv);		이것 대신 80번 줄을 입력했다. 이 줄을 주석해서 myId와 myNo의 값은 출력되진 않는다.

		return "test";

	}

	@RequestMapping("/clock.do")
	public String clock() { // Map modelMap ) {
//		Date d = new Date();
//		String ds = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(d);	
//		modelMap.put("now", ds);
		return "clock";
	}

	@RequestMapping("/data.do")
	@ResponseBody // 메서드의 반환값 자체가 응답 데이터로 전송되어야 함을 표시
	public Map<String, Object> data() {
		Date d = new Date();
		String ds = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(d);
		int n = (int) (Math.random() * 10);

		/*
		 * now : ds, num : n 
		 * XML 형식 
		 * 	<item> 
		 * 		<now>2020-07-22 11:42:42</now>
		 * 		<num>7</num>
		 * 	</item>
		 */
		/*
		 * JSON 형식 : 자바스크립트 객체표현과 동일하고, 2가지 다른점 존재 
		 * 	(1)속성이름을 문자열로 표현 
		 * 	(2)문자열은 쌍따옴표만 사용 
		 * var obj = { now : '2020-07-22 11:42:42', num : 7 }; //자바스크립트객체
		 * { "now" : "2020-07-22 11:42:42", "num" : 7 }; //JSON문자열
		 */

		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("now", ds);
		map.put("num", n);

		return map;
//		return "{ \"now\" : \"" + ds + "\", \"num\" : " + n + " }"; // "2020-07-22 11:42:42"
//		Jackson/ Gson
	}

}
