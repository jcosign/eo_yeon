

--회원 정보(member) 저장을 위한 테이블 생성
--회원 아이디 mem_id  문자열(최대 : 50 바이트)
--회원 비밀번호 mem_pass  문자열(최대 : 50 바이트)
--회원 이름 mem_name  문자열(최대 : 50 바이트)
--회원 포인트 mem_point  숫자(최대 : 10자리 정수)
CREATE TABLE member (
mem_id VARCHAR2(50),
mem_pass VARCHAR2(50),
mem_name VARCHAR2(50),
mem_point NUMBER(10,0),
PRIMARY KEY (mem_id)
);

INSERT INTO member
(mem_id, mem_pass, mem_name, mem_point)
VALUES
('a001','1234','고길동',100);

--//a001 회원의 포인트를 777로 변경하는 프로그램을 작성하세요.
UPDATE member SET mem_point = 77 where MEM_ID = 'a001';
commit;

SELECT * FROM MEMBER;

SELECT mem_id, mem_pass, mem_name, mem_point FROM MEMBER;
SELECT * FROM MEMBER;


CREATE TABLE student (
stu_no VARCHAR2(50), --학번
stu_name VARCHAR2(50), --이름
stu_score NUMBER(10,0), --성적
PRIMARY KEY (stu_no)
);

-- 게시판 
CREATE TABLE bbs(
bbs_no NUMBER(10,0), --글 번호
bbs_title VARCHAR2(100), --글제목
bbs_content CLOB,  --글내용
bbs_writer VARCHAR2(50), --작성자(아이디)
bbs_reg_date DATE DEFAULT SYSDATE, --글등록일(작성일)
bbs_count NUMBER(10,0) DEFAULT 0, -- 조회수
PRIMARY KEY ( bbs_no ),
FOREIGN KEY ( bbs_writer ) REFERENCES member (mem_id)
);

insert into bbs(bbs_no,bbs_title,bbs_content,bbs_writer)
values(seq_bbs_no.NEXTVAL,'테스트제목1','테스트내용1','a001');

SELECT * FROM bbs;

--시퀀스 생성(게시판 글번호를 위한 자동증가 정수값 생성)
CREATE SEQUENCE seq_bbs_no;

SELECT seq_bbs_no.NEXTVAL FROM DUAL;--시퀀스의 다음값 가져오기
SELECT seq_bbs_no.CURRVAL FROM DUAL;--시퀀스의 현재값 가져오기


insert into bbs(bbs_no,bbs_title,bbs_content,bbs_writer)
values(seq_bbs_no.NEXTVAL,'테스트제목2','테스트내용2','a002');

SELECT * FROM bbs;

--게시판 첨부파일 테이블
CREATE TABLE attach (
att_no NUMBER(10,0) PRIMARY KEY,	--첨부파일 번호
att_org_name VARCHAR2(255),		--원래 파일명
att_new_name VARCHAR2(255),		--서버에 저장한 파일명(충돌방지로 두개에 저장)
att_bbs_no NUMBER(10,0),	--첨부파일이 속한 게시글의 글번호
FOREIGN KEY (att_bbs_no) REFERENCES bbs (bbs_no)
);

select * from attach;

CREATE SEQUENCE seq_att_no;	--첨부파일번호 생성을 위한 시퀀스
select seq_att_no.nextval from dual;

SELECT bbs_no, bbs_title, bbs_content,bbs_writer, bbs_reg_date, bbs_count
att_no, att_org_name, att_new_name, att_bbs_no
FROM bbs inner join attach on bbs_no = att_bbs_no
WHERE bbs_no = 90;

select * from bbs;
select * from attach;

SELECT bbs_no, bbs_title, bbs_content,bbs_writer, bbs_reg_date, bbs_count
att_no, att_org_name, att_new_name, att_bbs_no
FROM bbs left outer join attach on bbs_no = att_bbs_no
WHERE bbs_no = 23;
--inner를 써서 첨부파일이 있는 글 번호를 써서 검색기능. outer를 써서 첨부파일 없어도 검색 가능.

-- 포인트 내림차순으로 정렬하여 2번째부터 4번째까지만 조회 
-- rownum 가상번호. 별명을 rnum으로 주고, 그 값을 출력해야 2번째부터 출력이 가능하다.
SELECT mem_id, mem_pass, mem_name, mem_point, rnum
FROM (SELECT mem_id, mem_pass, mem_name, mem_point, rownum rnum
		FROM (SELECT mem_id, mem_pass, mem_name, mem_point
			FROM member 
	 		order by mem_point desc)
		)
WHERE 2 <= rnum and rnum <= 4;
 
-- 좀 더 효율적인 방법
SELECT mem_id, mem_pass, mem_name, mem_point, rnum
FROM (SELECT mem_id, mem_pass, mem_name, mem_point, rownum rnum
		FROM (SELECT mem_id, mem_pass, mem_name, mem_point
			FROM member 
	 		order by mem_point desc)
		WHERE rownum <= 4)
WHERE 2 <= rnum;


insert into member (mem_id, mem_pass, mem_name, mem_point) values ('maleksidze0', 'wVQ18oA', 'Maisie Aleksidze', 498);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('cscamerden1', 'M0Nwac5', 'Cthrine Scamerden', 84);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('choogendorp2', 'o1qppwh', 'Carol Hoogendorp', 461);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('jbaistow3', 'lSeQ7jjuN8', 'Joachim Baistow', 142);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('fbremmell4', 'vo2RginMatl', 'Felipa Bremmell', 486);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('jbarthot5', 'ggSqAw0asm', 'Jeannie Barthot', 233);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('oipsly6', 'f1oxK0w', 'Othilia Ipsly', 139);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('sbenitti7', 'tS5XcbSBu50', 'Shandie Benitti', 268);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('rschimonek8', 'JtSqdWo', 'Roland Schimonek', 394);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('myurenin9', 'c3xjKqC', 'Mari Yurenin', 314);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('pidiensa', '8ViVtBaZ9EY', 'Pen Idiens', 451);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('smcmanusb', 'cqzRRJFC9', 'Shep McManus', 145);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ukalvinc', 'IWG7cs5Z', 'Ursulina Kalvin', 198);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('tdid', 'aFP3zsKkUPi', 'Titos Di Bartolomeo', 296);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('areemee', 'D5getBji', 'Arlina Reeme', 249);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('drobilartf', 'ViOL9XId', 'Davin Robilart', 149);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('drastallg', 'aqhRoh5', 'Daphne Rastall', 400);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('jechallierh', 'EZnCv4', 'Jordana Echallier', 446);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('mhonschi', 'tVFZ8qbGLcG', 'Maurita Honsch', 349);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('adikelsj', 'gFd3Kb6S', 'Ashely Dikels', 103);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('kblindk', 'fwutOk', 'Kiersten Blind', 429);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('cgallifordl', '197DFuETwZn', 'Cordelia Galliford', 85);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('jgilbodym', 'gc9jF4f', 'Javier Gilbody', 385);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ctatlowen', 'R9pU9F6gOSoK', 'Carlynne Tatlowe', 417);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('priglesfordo', 'QnDDGSjkCsA', 'Pegeen Riglesford', 78);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('olowdenp', 'M0oVqK4L', 'Odo Lowden', 92);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('lmancellq', 'O3wz7KKVuK', 'Leicester Mancell', 355);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('jolnerr', 'rlIwF1y9JF', 'Jenelle Olner', 289);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('hmells', 'P4OfNf', 'Hart Mell', 359);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ratlayt', 'LhVGE51pT7', 'Ricky Atlay', 256);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('znodinu', 'JBbVXUZ7Iv', 'Zonnya Nodin', 266);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('mtitfordv', 'CHsVf5faL', 'Mahalia Titford', 63);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('cmarvelw', 'KR7z5R', 'Christy Marvel', 245);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('tthynnex', 'vOTTdlMBxoR', 'Truda Thynne', 319);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('pmaddocky', 'MbxKCps', 'Pauletta Maddock', 199);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('mbarkleyz', 'hpX8FPCU', 'Maxy Barkley', 370);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('bstonehouse10', '46XqMJNDxirt', 'Bank Stonehouse', 263);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ede11', 'pE1Q9SEtwvB', 'Ernest De Ruel', 37);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('sminillo12', 'xAtez0', 'Shelley Minillo', 94);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('asteven13', 'ndWKml1yl', 'Adelaida Steven', 394);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('igrafham14', 'IymaMOGQh', 'Isabeau Grafham', 223);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('bpallent15', 'OjrJR2miQLZv', 'Benedict Pallent', 85);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ajose16', 'pR28uJc', 'Allister Jose', 462);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('hroutham17', 'aexvIasraB', 'Hasty Routham', 54);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('emanzell18', 'FHT01swdKfk', 'Ernie Manzell', 351);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('amcgaughie19', 'htcnipe4B', 'Aharon McGaughie', 360);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('glampard1a', 'AT4cJPeTKk', 'Gwendolin Lampard', 165);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('tdarlington1b', '8ir6Fu6', 'Timoteo Darlington', 492);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('pgoodwyn1c', 'nGnBGo', 'Perren Goodwyn', 156);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('maven1d', '0MmmMMUVZ7jA', 'Mae Aven', 457);

-- 게시판 댓글 테이블
CREATE TABLE reply (
rep_no NUMBER(10,0) PRIMARY KEY,	--댓글번호
rep_content CLOB,	--댓글내용
rep_writer VARCHAR2(50),	--댓글작성자아이디
rep_date DATE DEFAULT SYSDATE,	--댓글작성일
rep_bbs_no NUMBER(10,0),	--댓글이 속한 게시글 번호
FOREIGN KEY (rep_writer) REFERENCES member (mem_id),
FOREIGN KEY (rep_bbs_no) REFERENCES bbs (bbs_no)
);

select rep_no, rep_content, rep_writer, rep_date, rep_bbs_no
from reply;

CREATE SEQUENCE seq_rep_no;	--댓글번호 생성을 위한 시퀀스
select seq_att_no.nextval from dual;
