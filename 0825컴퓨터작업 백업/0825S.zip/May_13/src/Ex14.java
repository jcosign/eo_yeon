import java.util.Scanner;

public class Ex14 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("���� �Է�>> ");
		int score = scan.nextInt();
		char grd;
		
		if(score >= 90)
			grd = 'A';
		else if(score >= 80)
			grd = 'B';
		else if(score >=70)
			grd = 'C';
		else if(score >= 60 && score < 70)
			grd = 'D';
		else 
			grd = 'F';
		System.out.printf("����� ������ %c�Դϴ�.\n", grd);

	}

}
