import java.util.Scanner;

public class Ex1400 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("������ �Է��Ͻÿ�: ");
		int score = scan.nextInt();
		
		char grade = (score>=90)? 'A': ((score>=80)? 'B': ((score>=70)? 'C': (score>=60)? 'D': 'F'));
		System.out.println(grade + "����Դϴ�.");
		
	}

}
