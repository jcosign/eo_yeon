import java.util.Scanner;

public class Ex12 {

	public static void main(String[] args) {

//	char ch = scan.nextline().charAt(0);
		Scanner scan = new Scanner(System.in);
		System.out.println("Ű �Է�>> ");
		double height = scan.nextDouble();
		System.out.println("������ �Է�>> ");
		double weight = scan.nextDouble();
		double stdw = (height - 100) * 0.9;
		
		if(stdw < weight)
			System.out.println("��ü��");
		else if(weight >= stdw - 5 && weight <= stdw + 5)
			System.out.println("ǥ��");
		else
			System.out.println("��ü��");

	}

}
