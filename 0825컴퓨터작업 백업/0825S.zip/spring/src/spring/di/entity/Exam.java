package spring.di.entity;

public interface Exam {
	int total();
	float avg();
}