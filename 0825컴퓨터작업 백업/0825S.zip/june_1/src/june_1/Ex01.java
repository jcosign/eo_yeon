package june_1;

import java.util.Scanner;

public class Ex01 {

	public static void main(String[] args) {
//		int[][] arr = new int [2][3];
//		int[][] arr = {{10,20},{30,40},{50,60}};
		int[][] arr = new int [2][3];
		
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.printf("%4d",arr[i][j]);
			}
			System.out.println();
		}
	}
}
