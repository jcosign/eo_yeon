package june_1;

public class Ex08 {

	public static void main(String[] args) {
		String[] strArray = new String[3];
		for (int i = 0; i < strArray.length; i++) {
			
		}
		strArray[0] = "Java";
		strArray[1] = "C++";
		strArray[2] = "C#";
		strArray[2] = new String("java");
				
		System.out.println(strArray[0] == strArray[1]);
		System.out.println(strArray[0] == strArray[2]);
		System.out.println(strArray[0].equals(strArray[2]));

	}

}
