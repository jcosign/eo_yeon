package june_1;

import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {
		//Ű����� �Է¹ޱ�
		Scanner s = new Scanner(System.in);
		int[][] arr = new int[2][3];

		for (int i = 0; i < arr.length; i++) {
			System.out.printf("%d��: ", i+1);
			for (int j = 0; j < arr[i].length; j++) {
//								System.out.printf("(%d, %d)\n", i,j);
				arr[i][j] = s.nextInt();			
			}
			//			System.out.println();
		}

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.printf("%7d",arr[i][j]);
			}
		}
	}
}
