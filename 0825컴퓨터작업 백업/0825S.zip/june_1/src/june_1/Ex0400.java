package june_1;

import java.util.Scanner;

public class Ex0400 {

	public static void main(String[] args) {
		//������ ���� �� ���� �� ���ϱ�

		Scanner s = new Scanner(System.in);
		int[][] arr = new int[3][4];

		for (int i = 0; i < arr.length; i++) {
			System.out.printf("\n%d��: ", i+1);
			for (int j = 0; j < arr[i].length-1; j++) {
				arr[i][j] = s.nextInt();
				arr[i][j] = arr[i][3]+arr[i][j];
			}
		}

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.printf("%4d",arr[i][j]);

			}
		}
	}
}



//		arr[0][3] = arr[0][3]+arr[0][0];
//		arr[0][3] = arr[0][3]+arr[0][1];
//		arr[0][3] = arr[0][3]+arr[0][2];
//		arr[0][3] = arr[i][3]+arr[i][j];