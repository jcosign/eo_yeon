package may_27;

public class Ex01 {

	public static void main(String[] args) {
//		int[] intArray = {10,20,30};
//		intArray = new int[5];

//		boolean[] intArray;
//		intArray = new boolean[5];		
		
//		String[] intArray;
//		intArray = new String[5];		
		
//		for (int i = 0; i < intArray.length; i++) {
//			System.out.println(intArray[i]);
		
		String str1 = "ȫ�浿";
		String str2 = "�Ӳ���";
		String str3 = new String("ȫ�浿");
		String str4 = "�Ӳ���";
		
//		if(str1 == str2)
//			System.out.println("��ġ");
//		else
//			System.out.println("����ġ");
//		if(str3 == str4)
//			System.out.println("��ġ");
//		else
//			System.out.println("����ġ");
		
		if(str1.equals(str2))
			System.out.println("��ġ");
		else
			System.out.println("����ġ");
		if(str3 == str4)
			System.out.println("��ġ");
		else
			System.out.println("����ġ");	
		
		
		
		}
	}
