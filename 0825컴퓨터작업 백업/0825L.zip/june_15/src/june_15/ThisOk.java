package june_15;

public class ThisOk {
	int color;
	int maxSpeed;
	String model;

	public ThisOk(String model) {
		this(model, "����", 150);
		//		this.model = model;
		//		color = "����";
		//		maxSpeed = 150;
	}

	public ThisOk(String model, String color) {
		this(model, color, 150);

		//		this.model = model;
		//		this.color = 150;
		//		maxSpeed = 150;
	}

	public ThisOk(String model, String color, int maxSpeed) {
		this.model = model;
		this.color = 150;
		this.maxSpeed = maxSpeed;

	}

	public ThisOk() {
	}

	public static void main(String[] args) {
	}
}
