package june_15;

class StsticSample {
	public int n;
	public void g() {
		m = 20;
	}
	public void h() {
		m = 30;
	}
	public static int m;
	public static void f() {
		m = 5;
	}
}

public class Ex {
	public static void main(String[] args) {
		StsticSample.m = 10;
		
		StsticSample s1;
		s1 = new StsticSample();
		System.out.println(s1.m);
		s1.f();
		StsticSample.f();
		
	}
}
		/*StsticSample s1,s2;
		s1 = new StsticSample();
		s1.n = 5;
		s1.g();
		s1.m = 50; //static
		s2 = new StsticSample();
		s2.n = 8;
		s2.h();
		s2.f(); //static
		System.out.println(s1.m);*/
