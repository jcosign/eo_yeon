package may_20;

import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {
		int i = 1;		
		int sum = 0;	
		double avg;
		
		Scanner s = new Scanner(System.in);
		int menu;
		do {
			System.out.println("1. ���Ͽ���");
			System.out.println("2. ��������");
			System.out.println("�޴� ����>> ");
			menu = s.nextInt();

			if(menu<1 || menu>2) break;
//			Ȥ��	!(menu>=1 && menu <=2);

		}while(true);
		

	}

}
