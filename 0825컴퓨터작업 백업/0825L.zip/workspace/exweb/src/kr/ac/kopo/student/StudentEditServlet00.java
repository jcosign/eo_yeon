package kr.ac.kopo.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/student/edit.do")
public class StudentEditServlet00 extends HttpServlet{
	StudentDaoJdbc studentDao = new StudentDaoJdbc();
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");	

		StudentVo vo = new StudentVo();
		vo.setStuNo( req.getParameter("stuNo"));
		vo.setStuName( req.getParameter("stuName"));
		vo.setStuScore( Integer.parseInt(req.getParameter("stuScore")));
		
		int num = studentDao.updateStudent(vo);
		
		System.out.println(num + "���� �л� �߰�");
		resp.sendRedirect(req.getContextPath() + "/student/List.do");
	}

	
}






//package kr.ac.kopo.student;
//
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//@WebServlet("/student/edit.do")
//public class StudentEditServlet00 extends HttpServlet{
//	StudentDaoJdbc studentDao = new StudentDaoJdbc();
////   {
////      try {   
////      Class.forName("oracle.jdbc.OracleDriver");
////   } catch (ClassNotFoundException e) {
////      e.printStackTrace();
////   }
////   }
////
////   
////   String url = "jdbc:oracle:thin:@localhost:1521:xe";
////   String user = "com";
////   String password = "com01";
//
//   @Override
//   protected void service(HttpServletRequest req, HttpServletResponse resp) 
//      throws ServletException, IOException {
//      req.setCharacterEncoding("UTF-8");
//      
//      StudentVo vo = new StudentVo();
//      	vo.setStuNo( req.getParameter("stuNo"));
//		vo.setStuName( req.getParameter("stuName"));
//		vo.setStuScore( Integer.parseInt(req.getParameter("stuScore")));
//		
////      String stuNo = req.getParameter("stu_no");
////      String stuName = req.getParameter("stu_name");
////      int stuScore = Integer.parseInt(req.getParameter("stu_score"));
//      
//      int num = studentDao.updateStudent(vo);
//		
//		System.out.println(num + "���� ȸ�� �߰�");
//		resp.sendRedirect(req.getContextPath() + "/student/list.do");
//      
//   }
//}
//      
////      String sql = "UPDATE student SET stu_name = ?, stu_score=? WHERE stu_no = ?";
////      try (Connection conn = DriverManager.getConnection(url, user, password);
////      PreparedStatement pstmt = conn.prepareStatement(sql);
////            ) {      
////      pstmt.setString(1, stuName); 
////      pstmt.setInt(2, stuScore); 
////      pstmt.setString(3, stuNo); 
////
////      int num = pstmt.executeUpdate();
////      System.out.println(num + "���� ���ڵ� �߰�");
////      
////      } catch (SQLException e) {
////            e.printStackTrace();
////      }
//
//      