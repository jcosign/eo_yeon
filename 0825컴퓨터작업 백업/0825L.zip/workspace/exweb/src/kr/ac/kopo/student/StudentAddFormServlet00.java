package kr.ac.kopo.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/student/addform.do")	
public class StudentAddFormServlet00 extends HttpServlet{

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.getRequestDispatcher("/WEB-INF/jsp/student/stuAddForm.jsp").forward(req, resp);
		
	}
}





//package kr.ac.kopo.student;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//@WebServlet("/student/addform.do")	
//public class StudentAddFormServlet00 extends HttpServlet{
//
//	@Override
//	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		
//		req.getRequestDispatcher("/WEB-INF/jsp/student/stuAddForm.jsp").forward(req, resp);
//		
//	}
//}
////		resp.setContentType("text/html");
////		resp.setCharacterEncoding("UTF-8");
////		PrintWriter out = resp.getWriter();
////		out.println("<!DOCTYPE html>                  ");
////		out.println("<html>                           ");
////		out.println("<head>                           ");
////		out.println("<meta charset='UTF-8'>           ");
////		out.println("<title>�л�����</title> ");
////		out.println("</head>                          ");
////		out.println("<body>                           ");
////
////		out.println("	<h1>�л��߰�</h1>     ");
////
////		//ContextPath : ���� �����ø����̼�(������Ʈ)�� ���� ���
////		out.println("<form action='" + req.getContextPath() + "/student/add.do' method='post'>");
////		out.println	("�й�: <input type='text' name='stuNo' />  <br />");
////		out.println	("�̸�: <input type='text' name='stuName' />  <br />");
////		out.println	("����: <input type='text' name='stuScore' />  <br />");
////		out.println	("<input type='submit' value='����' />");
////		out.println ("</form>");
////	
////		out.println("</body>                          ");
////		out.println("</html>                          ");
////
////	}
////}
//
//
