package kr.ac.kopo.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/student/del.do")
public class StudentDelServlet00 extends HttpServlet {
	StudentDaoJdbc studentDao = new StudentDaoJdbc();

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String delid = req.getParameter("stuNo");

		int num = studentDao.deletStudent(delid);

		System.out.println(num + "���� �л� ����");
		resp.sendRedirect(req.getContextPath() + "/student/List.do");

	}


}




//package kr.ac.kopo.student;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//import java.util.Scanner;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//public class StudentDelServlet00 extends HttpServlet{
//	
////	public class StudentDelFormServlet {
//		{
//			try {
//
//				Class.forName("oracle.jdbc.OracleDriver");
//			} catch (ClassNotFoundException e) {
//				e.printStackTrace();
//			}	
//		}
//		String url = "jdbc:oracle:thin:@localhost:1521:xe"; 		
//		String user = "com";										
//		String password = "com01";		
//
//		@Override
//		protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//			req.setCharacterEncoding("UTF-8");
//			resp.setContentType("text/html");
//			resp.setCharacterEncoding("UTF-8");
//			
//			String stuNo = req.getParameter("stuNo"); 
//			String stuName = req.getParameter("stuName"); 
//			int stuScore = Integer.parseInt(req.getParameter("stuScore")); 
//			PrintWriter out = resp.getWriter();
//			
//			String sql = "INSERT INTO student (stu_no, stu_name, stu_score)"
//					+ "VALUES (?, ?, ?)";
//
//			try(
//					Connection conn = DriverManager.getConnection(url, user, password);
//					PreparedStatement pstmt = conn.prepareStatement(sql);	
//					) {
//				pstmt.setString(1, stuNo);		
//				pstmt.setString(2, stuName);	
//				pstmt.setInt(3, stuScore);	
//				int num = pstmt.executeUpdate(); 
//				out.println(num + "����ȸ�� ����");
//
//			} catch (SQLException e) {
//				e.printStackTrace();
//
//			}
//			out.println("<!DOCTYPE html>                  ");
//			out.println("<html>                           ");
//			out.println("<head>                           ");
//			out.println("<meta charset='UTF-8'>           ");
//			out.println("<title>ȸ������</title> ");
//			out.println("</head>                          ");
//			out.println("<body>                           ");
//
//			out.println("	<h1>ȸ������</h1>     ");
//
//			out.println ("<form action='" + req.getContextPath() + "/student/del.do' method='post'>");
//			out.println	("���̵�: <input type='text' name='stuNo' />  <br />");
//			out.println	("�̸�: <input type='text' name='stuName' />  <br />");
//			out.println	("����Ʈ: <input type='text' name='stuScore' />  <br />");
//			out.println	("<input type='submit' value='����' />");
//			out.println ("</form>");
//			
//			out.println ("</body>                          ");
//			out.println ("</html>                          ");
//
//		}
//		
//	}
//	
//
//
//
//
//
//
////package kr.ac.kopo.student;
////
////import java.io.IOException;
////import java.sql.Connection;
////import java.sql.DriverManager;
////import java.sql.PreparedStatement;
////import java.sql.SQLException;
////
////import javax.servlet.ServletException;
////import javax.servlet.annotation.WebServlet;
////import javax.servlet.http.HttpServlet;
////import javax.servlet.http.HttpServletRequest;
////import javax.servlet.http.HttpServletResponse;
////
////@WebServlet("/student/del.do")
////public class StudentDelServlet00 extends HttpServlet{
////	StudentDaoJdbc studentDao = new StudentDaoJdbc();
//////	{
//////		try {
//////
//////			Class.forName("oracle.jdbc.OracleDriver");
//////		} catch (ClassNotFoundException e) {
//////			e.printStackTrace();
//////		}	
//////	}
//////	String url = "jdbc:oracle:thin:@localhost:1521:xe"; 		
//////	String user = "com";										
//////	String password = "com01";	
////
////	@Override
////	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
////		System.out.print("������ ȸ���� ���̵� �Է��ϼ���.\n");
////		String delid = req.getParameter("stuNo");	
////		int num = studentDao.deletStudent(delid);
////		System.out.println(num + "�л����� ����");
////		resp.sendRedirect(req.getContextPath() + "/student/List.do");
////
////	}
////}
////
//////		{
//////			String sql = "DELETE FROM student WHERE stu_no = ?";		
//////			try(
//////					Connection conn = DriverManager.getConnection(url, user, password);
//////					PreparedStatement pstmt = conn.prepareStatement(sql);	
//////					){
//////				pstmt.setString(1, delid);
//////				int num = pstmt.executeUpdate();
//////				
//////			} catch(SQLException e) {
//////				e.printStackTrace();
//////			}
//////		}
////		
////
