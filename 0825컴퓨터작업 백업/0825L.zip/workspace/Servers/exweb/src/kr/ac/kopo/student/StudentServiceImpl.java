package kr.ac.kopo.student;

import java.util.List;

public class StudentServiceImpl implements StudentService{
	private StudentDao studentDao = StudentDaoBatis.getInstance(); 
	
	@Override
	public List<StudentVo> selectStuList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StudentVo selectStudent(int stuNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insertStudent(StudentVo vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateStudent(StudentVo vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deletStudent(int StuNo) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
