package may_18;

import java.util.Scanner;

public class Ex1100 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int i = 1;
		int S = scan.nextInt();
		
		while(i <= 10) {
		System.out.printf(" %d = %d + %d\n", S+i, S, i);
		i++;
		}
	}

}
//���� �߸���������.