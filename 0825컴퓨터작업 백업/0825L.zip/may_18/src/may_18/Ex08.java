package may_18;

import java.util.Scanner;

public class Ex08 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int cnt = 1;
		
		while(cnt <= 5) {
		System.out.println("Hellooooooo~~");
		cnt++;
		}
	}

}
