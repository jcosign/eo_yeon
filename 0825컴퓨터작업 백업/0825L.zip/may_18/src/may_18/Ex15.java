package may_18;

import java.util.Scanner;

public class Ex15 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int sum = 0;
		System.out.println("���� ��谪>> ");
		int n = scan.nextInt();
		
		for(int i = 1; i<=n; i++)
			sum += i;
		
		System.out.printf("��ü��:%d\n", sum);

	}

}
