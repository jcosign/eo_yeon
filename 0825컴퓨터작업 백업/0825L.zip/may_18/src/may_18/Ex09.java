package may_18;

import java.util.Scanner;

public class Ex09 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int i = 1;
		
		while(i <= 9) {
		System.out.printf(" %d x %d = %d\n", 7, i, 7*i);
		i++;
		}

	}

}
