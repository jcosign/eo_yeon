package q2;

public class Rectangle extends Shape{
	
	static double c, d;

	public Rectangle(double c, double d) {
		Rectangle.c = c;
		Rectangle.d = d;
	}

	public static double Area() {
		return c * d;
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getArea() {
		// TODO Auto-generated method stub
		
	}
}