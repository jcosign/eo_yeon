package q2;

public class Triangle {
	
	static double a, b, s;

	public Triangle(double a, double b) {
		Triangle.a = a;
		Triangle.b = b;
	}

	public double Area() {
		return (a * b) / 2.0; 

	}

}
