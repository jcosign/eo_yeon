package july_14;

public interface C extends A, B{
	void mathodC();
}
