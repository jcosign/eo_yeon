package july_14;

public class MultiEx {

	public static void main(String[] args) {
		A a = new MultiC();
		a.mathodA();
		
		B b = new MultiC();
		b.mathodB();

		C c = new MultiC();
		c.mathodA();
		c.mathodB();
		c.mathodC();
		
	}

}
