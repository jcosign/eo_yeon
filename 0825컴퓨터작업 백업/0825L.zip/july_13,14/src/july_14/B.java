package july_14;

public interface B {
	void mathodB();
}
