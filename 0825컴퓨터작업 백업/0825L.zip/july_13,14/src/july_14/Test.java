package july_14;

public class Test {
	static int x = 10;
	int y = 100;
}
