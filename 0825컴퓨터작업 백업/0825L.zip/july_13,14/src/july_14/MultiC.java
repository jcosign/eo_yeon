package july_14;

public class MultiC implements C{

	@Override
	public void mathodA() {
		System.out.println("A~");
		
	}

	@Override
	public void mathodB() {
		System.out.println("B~");
		
	}

	@Override
	public void mathodC() {
		System.out.println("C~");
		
	}
	
	
}
