package july_14;

public class TestEx {

	public int Tues() {
		Test t = new Test();
		int ok;
		ok = Test.x + t.y;
		return ok;
	}

	public static void main(String[] args) {
		TestEx e = new TestEx();
		System.out.println(e.Tues());
	}

}
