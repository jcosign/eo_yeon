package july_14;

public interface A {
	void mathodA();
}
