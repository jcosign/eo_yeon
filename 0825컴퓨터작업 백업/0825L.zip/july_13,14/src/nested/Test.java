package nested;

public class Test {
	int x = 10;
	int y = 20;

	public class B {
		B() {
			System.out.println("B ��ü�� ������");
		}

		int field1;

		// static int field2;
		void method1() {
		}
		// static void method2() {}
	}

	B field1 = new B();

	public int metgod1() {
		return x + y;
	}
}
