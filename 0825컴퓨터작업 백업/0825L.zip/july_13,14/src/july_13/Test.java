package july_13;

public class Test {
	static int x = 10;
	static int y;
	static { y = x + 20; }

}
