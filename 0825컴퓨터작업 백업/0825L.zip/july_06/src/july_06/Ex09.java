package july_06;

import java.util.Scanner;

public class Ex09 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		String str1 = "Java Programming";
		String str2 = new String("Java Programming");
		
		System.out.print(str1.equals(str2));
	}

}
