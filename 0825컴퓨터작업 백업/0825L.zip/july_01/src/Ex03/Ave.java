package Ex03;

import calculate.Calc;

public class Ave extends Calc{
	@Override
	protected
	int calculate() {
		int c3 = 0;
		int c2 = 0;
		int c1 = 0;
		return c1+c2+c3;
	}

}
