package Ex03;

public abstract class Calc00 {
	int a, b;

	void setValue(int a, int b) {
		this.a=a;
		this.b=b;
	}

	protected abstract int calculate();
}