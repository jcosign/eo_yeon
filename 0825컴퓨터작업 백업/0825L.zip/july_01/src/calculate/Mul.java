package calculate;

public class Mul extends Calc{
	@Override
	protected
		int calculate() {
			return a*b;
		}
}

