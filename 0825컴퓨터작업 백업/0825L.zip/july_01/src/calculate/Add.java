package calculate;

public class Add extends Calc{
	@Override
	protected
	int calculate() {
		return a+b;
	}
}
