package calculate00;

import java.util.Scanner;

public class Ulate {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		  
		  System.out.println("�� ������ �����ڸ� �Է��ϼ���.");
		  
		  int a = sc.nextInt();
		  int b = sc.nextInt();
		  String cc = sc.next();
		  char c = cc.charAt(0);
		  switch(c){
		  case '+':
		   Add plus = new Add();
		   plus.setValue(a, b);
		   System.out.println(plus.Calc());
		   break;
		   
		  case '-':
		   Sub sub = new Sub();
		   sub.setValue(a, b);
		   System.out.println(sub.Calc());
		   break;
		   
		  case '*':
		   Mul mul = new Mul();
		   mul.setValue(a, b);
		   System.out.println(mul.Calc());
		   break;
		   
		  case '/':
		   Div div = new Div();
		   div.setValue(a, b);
		   System.out.println(div.Calc());
		   break;
		   
		   default:
		    System.out.println("�߸��� ���Դϴ�.");
		    break;
		  }
		 }
		}