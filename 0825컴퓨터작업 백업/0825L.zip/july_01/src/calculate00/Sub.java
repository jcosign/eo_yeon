package calculate00;

class Sub extends Calc{
	void setValue(int a, int b) {
		this.a=a;
		this.b=b;
	}
	
		int Calc() {
			return a-b;
	}
}
