import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		System.out.println("������ ���� �Է�");
		int x = scan.nextInt();
		int y = scan.nextInt();
		int z = scan.nextInt();
		int max;
		
		max = x>y? x: y;
		max = max>z?max:z;
		
		System.out.printf("�ִ�:%d\n", max);
	}

}
