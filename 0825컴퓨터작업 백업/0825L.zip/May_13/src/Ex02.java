import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		System.out.println("���� �Է�>> ");
		int year = scan.nextInt();
		
		boolean bool = ((year%4 == 0) && (year%100 != 0)) || (year%400 == 0);
		
	}

}
