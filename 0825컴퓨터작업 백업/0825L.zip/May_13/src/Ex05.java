import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		int x = 1;
		
		System.out.printf("%15s%15s%15s\n", "Int", "Square", "Cube");
		System.out.printf("%15d%15d%15d\n", x, x*x, x*x*x);
		x++;
		System.out.printf("%15d%15d%15d\n", x, x*x, x*x*x);
		x++;
		System.out.printf("%15d%15d%15d\n", x, x*x, x*x*x);
		x++;
		System.out.printf("%15d%15d%15d\n", x, x*x, x*x*x);
		x++;
		
	}

}
