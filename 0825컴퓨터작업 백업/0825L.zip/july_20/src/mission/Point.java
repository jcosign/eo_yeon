package mission;

import java.util.Scanner;

public class Point {
	private long distance;
	
	public Point() {}
	
	public long getBalance() {
		return distance;
	}
	
	public void distance(int result) throws PointException {
		
		
//		if(x1 == x2 && y1 == y2){
		throw new PointException("�� �� ������ �Ÿ���: " + (result-distance) + "�Դϴ�.");
		}
//		distance = (long) Math.sqrt(Math.pow(x1, 2)-2*x1*x2+Math.pow(x2, 2) + (Math.pow(y1, 2)-2*y1*y2+Math.pow(y2, 2)));
	}
	
//}
