package mission;

public class PointException extends Exception {
	public PointException() {}
	public PointException(String message) {
		super(message);
	}

}
