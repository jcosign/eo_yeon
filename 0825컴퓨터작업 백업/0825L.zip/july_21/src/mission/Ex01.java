package mission;

import java.util.ArrayList;
import java.util.Scanner;

public class Ex01 {
	/* Q1. Scanner 클래스로 –1이 입력될 때까지 양의 정수를 입력받아 벡터에 저장하고 벡터를 검색하여 가장 큰 수를 출력하는 프로그램을
	 * 작성하시오. (단, Vector 컬렉션을 이용하세요.)
	 * 
	 * 정수(-1이 입력될 때까지)>>10 9 93 77 88 –1 가장 큰 수는 93
	 */
	public static void main(String[] args) {
		// 문자열만 삽입가능한 ArrayList 컬렉션 생성
		ArrayList<String> a = new ArrayList<String>();

		Scanner scanner = new Scanner(System.in);

		for (int i = 0; i < 4; i++) {
			System.out.println("정수를 입력하세요>>");
			String s = scanner.next(); // 키보드로부터 이름 입력
			a.add(s); // ArrayList 컬렉션에 삽입
		}
		// ArrayList에 들어 있는 모든 이름 출력
//		for (int i = 0; i < a.size(); i++) {
//			// ArrayList의 i번째 문자열 얻어오기
//			String name = a.get(i);
//			System.out.println(name + " ");
//		}
		// 가장 긴 이름 출력
		int longestIndex = 0;
		for (int i = 0; i < a.size(); i++) {
			if (a.get(longestIndex).length() < a.get(i).length())
				longestIndex = i;
		}
		System.out.println("\n가장 긴 이름은 : " + a.get(longestIndex));
	}

}
