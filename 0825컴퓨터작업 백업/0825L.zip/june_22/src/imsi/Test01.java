package imsi;

import monday.Goods;

public class Test01 {

	public static void main(String[] args) {
		Goods ok = new Goods();
		ok.name = "TV";
		System.out.println(ok);

	}
}