package imsi;

import monday.Goods;

class User{
	String name;
	String type;

	public User(String name, String type) {
		this.name = name;
		this.type = type;
	}
}

class Student extends User{
	public Student(String name, String type) {
		super(name, type);
	}
}

class Staff extends User{
	public Staff(String name, String type) {
		super(name, type);
	}
}

class Citizen extends User{
	public Citizen(String name, String type) {
		super(name, type);
	}

}

public class Test {
	public void useLibrary(User user) {
		System.out.println(user.type + " " + user.name + "�� �������� �̿��մϴ�.");
	}

//	public void useLibrary(Staff staff) {
//		System.out.println(staff.type + " " + staff.name + "�� �������� �̿��մϴ�.");
//	}
//	
//	public void useLibraary(Citizen citizen) {
//		System.out.println(citizen.type + " " + citizen.name + "�� �������� �̿��մϴ�.");
//	}

	public static void main(String[] args) {
		Test tt = new Test();
		User user = new Student("ȫ�浿","�л�");
		tt.useLibrary(user);  // Student s1 = new Student();

		User user1 = new Staff("�Ӳ���","������");
		tt.useLibrary(user1);
	}

}