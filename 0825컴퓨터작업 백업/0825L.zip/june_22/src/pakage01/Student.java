package pakage01;

import java.util.Scanner;

public class Student extends person{
	private String getweight;

	void set() {
		Scanner s = new Scanner(System.in);	
		System.out.println("���̸� �Է��Ͻÿ�: ");
		age = s.nextInt();
		System.out.println("�̸��� �Է��Ͻÿ�: ");
		name = s.next();
		System.out.println("Ű�� �Է��Ͻÿ�: ");
		height = s.nextInt();
		System.out.println("���Ը� �Է��Ͻÿ�: ");
		setWeight(s.nextInt());
	}

	public static void main(String[] args) {
		Student s = new Student();
		s.set();

		System.out.println("age: " + s.age + ", " + "name: " + s.name + ", " + "height: " + s.height + ", " + "weight: " + s.getWeight());
	}

}
