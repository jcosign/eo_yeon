package june_1;

public class Ex10 {

	public static void main(String[] args) {
		int[] arr = {10,20,30,40,50};
		
		int sum = 0;
		
		for(int n: arr) {
			sum += n;
		}
		System.out.printf("��ü��:%d\n", sum);

	}

}
