package june_1;

import java.util.Scanner;

public class Ex06 {

	public static void main(String[] args) {
		// ������ ���� �߻���Ų �� �� �� ���� �ִ��� ���Ͻÿ�.

		int[][] arr = new int[3][3];

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = (int)(Math.random()*101);
			}
		}

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.printf("%4d", arr[i][j]);
			}
			System.out.println();
		}

		System.out.println();

		for (int i = 0; i < arr.length; i++) {
			int max = arr[i][0];

			for (int j = 0; j < arr[i].length; j++) {
				if(max < arr[i][j])
					max = arr[i][j];
			}
			System.out.printf("%d���� �ִ�: %d\n", i+1, max);
		}
	}
}

