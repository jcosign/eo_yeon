
public class Ex08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		boolean stop = true;
		if(stop) {
					System.out.println("�����մϴ�.");
		} else {
					System.out.println("�����մϴ�.");
		}
	}

}
