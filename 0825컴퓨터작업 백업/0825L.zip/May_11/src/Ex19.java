
public class Ex19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a;
		float b;
		
		a = (int) 123.45f;
		b = 200;
		
		
		System.out.printf("a�� �� ==> %d \n", a);
		System.out.printf("b�� �� ==> %f \n", b);
	}

}
