import java.util.Scanner;

public class Ex06 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		int[] score = new int[5];
		int sum = 0;
		
		for(int i = 0; i < score.length; i++) {
			System.out.printf("%d�� ���� ����: ", i);
			score[i] = s.nextInt();
			sum += score[i];
		}
		
		double avg = (double)sum/score.length;
		System.out.printf("��ü �������:%f\n", avg);
		
	}

}
