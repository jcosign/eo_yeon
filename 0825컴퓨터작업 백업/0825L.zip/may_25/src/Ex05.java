import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s = new Scanner(System.in);
		
//		int[] arr = {10, 20, 30, 40, 50};
		int[] a = new int[] {10, 20, 30, 40, 50};
		
//		for(int i = 0; i < arr.length; i++) {
//			System.out.printf("%5d", arr[i]);
		
		for(int i = 0; i < a.length; i++) {
			System.out.printf("����%d: ", i+1);
			a[i] = s.nextInt();
		}
		for (int i = 0; i < a.length; i++) {
			System.out.printf("%4d", a[i]);
		}
	}
	}


