//package package2;
//
//public class CPoint {
//	int x, y;
//	
//	public CPoint(int x, int y) {
//		
//	}
//
//	public void main(String[] args){
//		
//		CPoint a = new CPoint(2, 3);
//		
//		CColorPoint b = new CColorPoint(3, 4, "red");
//		
//		a.show();
//		
//		b.show();
//		
//	}
//
//	protected void show() {
//		// TODO Auto-generated method stub
//		
//	}
//
//}
//
//����