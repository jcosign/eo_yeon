//package package2;
//
//class color {
//	String color;
//	public void setcolor(String color) {
//		this.color = color;
//	}
//	public String getcolor() {
//		return color;
//	}
//}
//	
//	public class CColorPoint extends CPoint{
//		public CColorPoint(int x, int y, String color) {
//			
//		}
//
//
//		public String getcolor() {
//			return null;
////					super.getcolor();
//		}
//	
//
//	public void main(String[] args) {
//
//
//	}
//
//}
//����