package shape;

public class Shape {
	public void draw() {
		System.out.println("Shape");
	}

	public void test() {
		System.out.println("Test");
	}
}

class Line extends Shape{
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		super.draw();
	}
		
//	public void draw() {
//		System.out.println("Line");
//	}

}


class Rectangle extends Shape{
	@Override
	public void draw() {
		System.out.println("rectangle");
	}
	
//	public void draw() {
//		System.out.println("Rectangle");
//	}

}

class Circle extends Shape{
	@Override
	public void draw() {
		System.out.println("circle");
	}
	
//	public void draw() {
//		System.out.println("Circle");
//	}

}

//class Line extends Shape{}
//class Rectangle extends Shape{}
//class Circle extends Shape{}