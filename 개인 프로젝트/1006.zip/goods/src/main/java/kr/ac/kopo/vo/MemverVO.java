package kr.ac.kopo.vo;

import java.util.Date;

public class MemverVO {

/*	comId      varchar2(50)    not null,  			--아이디
    comPass    varchar2(100)   not null,  			--비밀번호
    comName    varchar2(30)    not null,   			--회사이름
    comPhon    varchar2(20)    not null,   			--회사번호
    repName    varchar2(30)    null,    			--담당자(선택)    
    repPhon    varchar2(20)    null,   				--담당자번호(선택)
    comAddr    varchar2(20)    not null,   			--주소
    regiDate   date            default sysdate,  	--가입날짜
    verify     number          default 0,    		--메일 인증여부(기본값 0, 인증시 0아님)
 */
	
	private String comId;
	private String comPass;
	private String comName;
	private String comPhone;
	private String repName;
	private String repPhone;
	private String comAddr;
	private Date regiDate;
	private int verify;
	
	public String getComId() {
		return comId;
	}
	public void setComId(String comId) {
		this.comId = comId;
	}
	public String getComPass() {
		return comPass;
	}
	public void setComPass(String comPass) {
		this.comPass = comPass;
	}
	public String getComName() {
		return comName;
	}
	public void setComName(String comName) {
		this.comName = comName;
	}
	public String getComPhone() {
		return comPhone;
	}
	public void setComPhone(String comPhone) {
		this.comPhone = comPhone;
	}
	public String getRepName() {
		return repName;
	}
	public void setRepName(String repName) {
		this.repName = repName;
	}
	public String getRepPhone() {
		return repPhone;
	}
	public void setRepPhone(String repPhone) {
		this.repPhone = repPhone;
	}
	public String getComAddr() {
		return comAddr;
	}
	public void setComAddr(String comAddr) {
		this.comAddr = comAddr;
	}
	public Date getRegiDate() {
		return regiDate;
	}
	public void setRegiDate(Date regiDate) {
		this.regiDate = regiDate;
	}
	public int getVerify() {
		return verify;
	}
	public void setVerify(int verify) {
		this.verify = verify;
	}

	
	
}
