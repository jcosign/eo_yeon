package kr.co.kopo.service;

import java.util.List;

import kr.co.kopo.model.Coffee;
import kr.co.kopo.util.Pager;

public interface CoffeeService {

	List<Coffee> list(Pager pager);

	void add(Coffee item);

	void delete(int beanid);

	Coffee item(int beanid);

	void update(Coffee item);

	

	

	

	

}
