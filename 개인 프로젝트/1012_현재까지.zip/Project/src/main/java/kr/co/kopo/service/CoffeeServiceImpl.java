package kr.co.kopo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.kopo.dao.CoffeeDao;
import kr.co.kopo.model.Coffee;
import kr.co.kopo.util.Pager;

@Service
public class CoffeeServiceImpl implements CoffeeService {

	@Autowired
	CoffeeDao dao;

	@Override
	public List<Coffee> list(Pager pager) {
		int total = dao.total(pager);
		
		pager.setTotal(total);
		return dao.list(pager);
	}

	@Override
	public void add(Coffee item) {
		dao.add(item);
	}

	@Override
	public void delete(int beanid) {
		dao.delete(beanid);
	}

	@Override
	public Coffee item(int beanid) {
		return dao.item(beanid);
	}

	@Override
	public void update(Coffee item) {
		dao.update(item);
	}


}
