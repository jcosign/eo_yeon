package kr.co.kopo.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.kopo.model.Customer;
import kr.co.kopo.util.Pager;

@Repository
public class CustomerDaoImple implements CustomerDao {

	@Autowired
	SqlSession sql;
	
	@Override
	public int checkId(String id) {
		return sql.selectOne("Customer.checkId", id);
	}

	@Override
	public Customer login(Customer item) {
		return sql.selectOne("Customer.login", item);
	}

	@Override
	public int total(Pager pager) {
		return sql.selectOne("Customer.total", pager);
	}

	@Override
	public List<Customer> list(Pager pager) {
		return sql.selectList("Customer.list", pager);
	}

	@Override
	public void add(Customer item) {
		sql.insert("Custmoer.add", item);
	}

	@Override
	public Customer item(int custid) {
		return sql.selectOne("Customer.item", custid);
	}

	@Override
	public void update(Customer item) {
		sql.update("Customer.update", item);
	}

	@Override
	public void delete(int custid) {
		sql.delete("Customer.delete", custid);
	}

}
