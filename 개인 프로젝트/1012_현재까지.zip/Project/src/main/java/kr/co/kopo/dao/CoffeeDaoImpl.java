package kr.co.kopo.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.kopo.model.Coffee;
import kr.co.kopo.util.Pager;

@Repository
public class CoffeeDaoImpl implements CoffeeDao {

	@Autowired
	SqlSession sql;
	
	
	@Override
	public List<Coffee> list(Pager pager) {
		return sql.selectList("Coffee.list", pager);
	}
	
	@Override
	public int total(Pager pager) {
		return sql.selectOne("Coffee.total", pager);
	}

	@Override
	public void add(Coffee item) {
		sql.insert("Coffee.add", item);
	}

	@Override
	public void delete(int beanid) {
		sql.delete("Coffee.delete", beanid);
	}

	@Override
	public void update(Coffee item) {
		sql.update("Coffee.update", item);
	}

	@Override
	public Coffee item(int beanid) {
		return sql.selectOne("Coffee.item", beanid);
	}


}
