package kr.co.kopo.dao;

import java.util.List;

import kr.co.kopo.model.Customer;
import kr.co.kopo.util.Pager;

public interface CustomerDao {

	int checkId(String id);

	Customer login(Customer item);

	int total(Pager pager);

	List<Customer> list(Pager pager);

	void add(Customer item);

	Customer item(int custid);

	void update(Customer item);

	void delete(int custid);

}
