package kr.co.kopo.model;

public class Detail {

	int detailid;
	int orderid;
	int beanid;
	int amount;
	
	public int getDetailid() {
		return detailid;
	}
	public void setDetailid(int detailid) {
		this.detailid = detailid;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getBeanid() {
		return beanid;
	}
	public void setBeanid(int beanid) {
		this.beanid = beanid;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
}
