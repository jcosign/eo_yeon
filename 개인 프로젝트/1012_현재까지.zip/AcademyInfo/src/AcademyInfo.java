import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class AcademyInfo {

	public static void main(String[] args) {
		final boolean sql = true;
		
		String url="http://openapi.academyinfo.go.kr/openapi/service/rest/BasicInformationService/getNoticeUniversitySearchList?serviceKey=0vCtKJhAMokqjZzr%2F4LVCdfB8FDekgL77VZb65izGxQQpmbdoXRVULiV7HR0yzW4Anev6HA%2BBXX6mdHwLwX44Q%3D%3D&svyYr=2020&schlId=&schlKrnNm=&clgcpDivCd=&schlDivCd=&schlKndCd=&znCd=&estbDivCd=&numOfRows=999&pageNo=&";
		
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet req = new HttpGet(url);
		
		try {
//			file객체를 만들어 file을 FileWriter가 감싸고, 이걸 BufferedWriter가 감싼다.(out폴더에 저장됨) 읽기 쉽게 하기 위해
			File file;
			
			if(sql)
				file = new File("sql/academy_list.sql");
			else
				file = new File("out/academy_list.txt");
			
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			
			HttpResponse res = client.execute(req);
			
			if(res.getStatusLine().getStatusCode() == 200) {
				String body = EntityUtils.toString(res.getEntity(), "UTF-8");
				
//				System.out.println(body);
				
				ObjectMapper mapper = new XmlMapper();
				
				AcademyResponse result = mapper.readValue(body, AcademyResponse.class);
				
				System.out.println(result.getHeader().getResultCode());
				System.out.println(result.getHeader().getResultMsg());
				
				for (Item item : result.getBody().getItems()) {
//					System.out.println(item.getSchlKrnNm()); 
					System.out.println(item);
					
					if(sql)
						writer.write(item.toSQL());
					else
						writer.write(item.toString());
					
					writer.newLine();
				}
				
				writer.close();			//닫아주기
				
			}		
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}

}
