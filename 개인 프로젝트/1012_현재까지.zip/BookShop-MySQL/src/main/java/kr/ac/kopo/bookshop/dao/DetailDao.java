package kr.ac.kopo.bookshop.dao;

import kr.ac.kopo.bookshop.model.Detail;

public interface DetailDao {

	void add(Detail detail);

}
