package kr.ac.kopo;

public interface Item {
	int getCode();
	String getName();
}
