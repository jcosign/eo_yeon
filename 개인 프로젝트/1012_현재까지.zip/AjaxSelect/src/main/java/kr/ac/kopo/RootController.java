package kr.ac.kopo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class RootController {
	List<Zone> list;
	
	public RootController() {
		list = new ArrayList<Zone>();
		
		for(int index=1; index < 10; index++) {
			Zone zone = new Zone();
			
			zone.setCode(index);
			zone.setName(index + " 지역");
			
			List<Campus> list_campus = new ArrayList<Campus>();
			for(int campus_i=1; campus_i < 10; campus_i++) {
				Campus campus = new Campus();
				
				campus.setCode(campus_i);
				campus.setName(campus_i + " 대학 ("+ index +")");
				
				List<Depart> list_depart = new ArrayList<Depart>();
				for(int depart_i=1; depart_i < 10; depart_i++) {
					Depart depart = new Depart();
					
					depart.setCode(depart_i);
					depart.setName(depart_i + " 학과 ("+ index +","+ campus_i +")");
					
					list_depart.add(depart);
				}
				
				campus.setDepart(list_depart);
				
				list_campus.add(campus);					
			}
			
			zone.setCampus(list_campus);
			
			list.add(zone);
		}
	}
	
	@GetMapping("/")
	String index() {		
		return "index";
	}
	
	@GetMapping("/html")
	String html(Model model, @RequestParam(name="zone", required=false) Integer zoneCode, @RequestParam(name="campus", required=false) Integer campusCode) {		
		model.addAttribute("list", list);
		
		if(zoneCode != null) {
			for(Zone zone : list) {
				if(zone.getCode() == zoneCode) {
					model.addAttribute("campus", zone.campus);
					
					if(campusCode != null) {
						for(Campus campus : zone.campus) {
							if(campus.getCode() == campusCode) {
								model.addAttribute("depart", campus.depart);
								break;
							}
						}
					}
					
					break;
				}
			}
		}		
		
		return "html";
	}
	
	@GetMapping("/ajax")
	String ajax() {
		return "ajax";
	}
	
	@ResponseBody
	@GetMapping(value="zone", produces="application/json; charset=utf8") 
	String zone() {
		return makeJson(list);
	}
	
	@ResponseBody
	@GetMapping(value="/campus", produces="application/json; charset=utf8")
	String campus(@RequestParam(name="zone") int zoneCode) {
		Zone zone = new Zone();
		for(Zone item : list) {
			if(zoneCode == item.getCode()) {
				zone = item;
				break;
			}
		}
		
		return makeJson(zone.getCampus());
	}
	
	@ResponseBody
	@GetMapping(value="/depart", produces="application/json; charset=utf8")
	String depart(@RequestParam(name="zone") int zoneCode, @RequestParam(name="campus") int campusCode) {
		Campus campus = new Campus();
		for(Zone item : list) {
			if(zoneCode == item.getCode()) {
				for(Campus campus_item : item.getCampus()) {
					if(campusCode == campus_item.getCode()) {
						campus = campus_item;
						break;
					}
				}
				
				break;
			}
		}
				
		return makeJson(campus.getDepart());
	}

	private String makeJson(List<? extends Item> list) {
		String json = "[";

		for(Item item : list) {
			if(!json.equals("["))
				json += ",";
			
			json += "{";
			
			json += "\"code\":";
			json += item.getCode();
			
			json += ", \"name\":";
			json += "\"" + item.getName() + "\"";
			
			json += "}";
		}
		
		json += "]";
		
		return json;
	}
}
