package kr.ac.kopo;

import java.util.List;

public class Campus implements Item {
	int code;
	String name;
	
	List<Depart> depart;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Depart> getDepart() {
		return depart;
	}

	public void setDepart(List<Depart> depart) {
		this.depart = depart;
	}
}
