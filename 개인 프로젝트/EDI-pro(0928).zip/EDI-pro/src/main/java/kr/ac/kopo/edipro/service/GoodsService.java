package kr.ac.kopo.edipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.edipro.dao.GoodsDao;
import kr.ac.kopo.edipro.model.Goods;

@Service
public interface GoodsService {
	
	@Autowired
	GoodsDao dao;

	List<Goods> getList();
	
	void delete(int goodsid);
	
	void add(Goods item);
	
	Goods getItem(int goodsid);
	
	void update(Goods item);
}
