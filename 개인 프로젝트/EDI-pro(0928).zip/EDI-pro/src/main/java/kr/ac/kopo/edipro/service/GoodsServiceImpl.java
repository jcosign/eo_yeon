package kr.ac.kopo.edipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.edipro.dao.GoodsDao;
import kr.ac.kopo.edipro.model.Goods;

@Service
public class GoodsServiceImpl implements GoodsService {

	@Autowired
	GoodsDao dao;
	
	@Override
	public List<Goods> getList() {
		return dao.getList();
	}

	@Override
	public void delete(int goodsid) {
		dao.delete(goodsid);
	}

	@Override
	public void add(Goods item) {
		dao.add(item);
	}

	@Override
	public Goods getItem(int goodsid) {
		return dao.getItem(goodsid);
	}

	@Override
	public void update(Goods item) {
		dao.update(item);
	}

}
