package kr.ac.kopo.edipro.dao;

import java.util.List;

import kr.ac.kopo.edipro.model.Goods;

public interface GoodsDao {

	List<Goods> getList();

	void delete(int goodsid);

	void add(Goods item);

	Goods getItem(int goodsid);

	void update(Goods item);
}
