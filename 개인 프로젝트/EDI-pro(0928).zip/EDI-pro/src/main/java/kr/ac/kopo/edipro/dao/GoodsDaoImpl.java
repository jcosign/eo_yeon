package kr.ac.kopo.edipro.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.edipro.model.Goods;

@Repository
public class GoodsDaoImpl implements GoodsDao {
	@Autowired
	SqlSession sql;

	@Override
	public List<Goods> getList() {
		return sql.selectList("goods.getList");
	}

	@Override
	public void delete(int goodsid) {
		sql.delete("goods.delete", goodsid);
	}

	@Override
	public void add(Goods item) {
		sql.insert("goods.add", item);
	}

	@Override
	public Goods getItem(int goodsid) {
		return sql.selectOne("goods.getItem", goodsid);
	}

	@Override
	public void update(Goods item) {
		sql.update("goods.update", item);
	}
}
