package kr.ac.kopo.edipro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.ac.kopo.edipro.model.Goods;
import kr.ac.kopo.edipro.service.GoodsService;

@Controller
@RequestMapping("/goods")
public class GoodsController {

	final String path = "goods/";
	@Autowired
	GoodsService service;

	@RequestMapping(value = "/list")
	String list(Model model) {
		List<Goods> list = service.getList();
		model.addAttribute("list", list);
		return path + "list";
	}

	@RequestMapping(value = "/delete")
	String delete(int goodsid) {
		service.delete(goodsid);
		return "redirect:list";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	String add() {
		return path + "add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	String add(Goods item) {
		service.add(item);
		return "redirect:list";
	}

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	String update(int goodsid, Model model) {
		Goods item = service.getItem(goodsid);
		model.addAttribute("item", item);
		return path + "update";
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	String update(Goods item) {
		service.update(item);
		return "redirect:list";
	}
}