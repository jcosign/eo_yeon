package kr.ac.kopo.bbs;

public interface AttachDao {
	public int insertAttach(AttachVo vo);
}
